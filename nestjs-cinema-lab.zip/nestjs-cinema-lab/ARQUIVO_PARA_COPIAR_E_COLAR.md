# Arquivo pronto para copiar e colar

Este arquivo acompanha o projeto `.zip` e serve como versão textual com os principais arquivos.

## `prisma/schema.prisma`

```prisma
generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider = "sqlite"
  url      = env("DATABASE_URL")
}

model Profile {
  id        String   @id @default(uuid())
  name      String
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt
  users     User[]
}

model User {
  id        String   @id @default(uuid())
  email     String   @unique
  password  String
  name      String
  profileId String
  profile   Profile  @relation(fields: [profileId], references: [id])
  address   Address?
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt
}

model Address {
  id        String   @id @default(uuid())
  street    String
  number    Int
  city      String
  state     String
  zipCode   String
  userId    String   @unique
  user      User     @relation(fields: [userId], references: [id], onDelete: Cascade)
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt
}
```

## `src/main.ts`

```ts
import { ValidationPipe } from '@nestjs/common';
import { NestFactory } from '@nestjs/core';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import { AppModule } from './app.module';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      forbidNonWhitelisted: true,
      transform: true,
    }),
  );

  const config = new DocumentBuilder()
    .setTitle('NestJS Cinema Lab API')
    .setDescription(
      'API RESTful para gerenciamento de perfis, usuários e endereços com NestJS, Prisma e Swagger.',
    )
    .setVersion('1.0.0')
    .build();

  const document = SwaggerModule.createDocument(app, config);
  SwaggerModule.setup('api/docs', app, document);

  await app.listen(3000);
}

bootstrap();
```

## Observação

O restante dos arquivos já está organizado dentro do `.zip` entregue junto com esta resposta.
