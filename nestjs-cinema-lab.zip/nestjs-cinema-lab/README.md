# CMP2305 - N1 - NestJS

Projeto completo em NestJS com Prisma, SQLite, Swagger e validação para CRUD de:
- Profile
- User
- Address

## 1) Como executar

```bash
npm install
npx prisma generate
npx prisma migrate dev --name init_entities
npm run start:dev
```

## 2) Swagger

Abra no navegador:

```text
http://localhost:3000/api/docs
```

## 3) Endpoints

### Profile
- `POST /profile`
- `GET /profile`
- `GET /profile/:id`
- `PATCH /profile/:id`
- `DELETE /profile/:id`

### User
- `POST /user`
- `GET /user`
- `GET /user/:id`
- `PATCH /user/:id`
- `DELETE /user/:id`

### Address
- `POST /address`
- `GET /address`
- `GET /address/:id`
- `PATCH /address/:id`
- `DELETE /address/:id`

## 4) Ordem sugerida de testes

### Criar perfis
```json
{
  "name": "ADMIN"
}
```

```json
{
  "name": "USER"
}
```

### Criar usuário
> Substitua `PROFILE_ID_AQUI` pelo UUID criado no passo anterior.

```json
{
  "email": "admin@email.com",
  "password": "123456",
  "name": "Administrador do Sistema",
  "profileId": "PROFILE_ID_AQUI"
}
```

### Criar segundo usuário
```json
{
  "email": "user@email.com",
  "password": "123456",
  "name": "Usuário Comum",
  "profileId": "PROFILE_ID_AQUI"
}
```

### Criar endereço
> Substitua `USER_ID_AQUI` pelo UUID do primeiro usuário.

```json
{
  "street": "Avenida Central",
  "number": 100,
  "city": "Goiânia",
  "state": "GO",
  "zipCode": "74000-000",
  "userId": "USER_ID_AQUI"
}
```

### Atualizar usuário
```json
{
  "name": "Administrador Atualizado"
}
```

## 5) Observações implementadas

- PrismaModule global
- SQLite configurado por padrão
- DTOs com `class-validator`
- Swagger configurado em `/api/docs`
- Relacionamento 1:N entre `Profile` e `User`
- Relacionamento 1:1 entre `User` e `Address`
- `onDelete: Cascade` em `Address -> User`
- Resposta de `User` sem expor `password`

## 6) Estrutura resumida

```text
src/
  address/
  profile/
  prisma/
  user/
  app.module.ts
  main.ts
prisma/
  schema.prisma
```
