import {
  BadRequestException,
  ConflictException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { Prisma } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { CreateAddressDto } from './dto/create-address.dto';
import { UpdateAddressDto } from './dto/update-address.dto';

@Injectable()
export class AddressService {
  constructor(private readonly prisma: PrismaService) {}

  async create(data: CreateAddressDto) {
    await this.ensureUserExists(data.userId);

    try {
      return await this.prisma.address.create({
        data,
        include: {
          user: {
            select: {
              id: true,
              email: true,
              name: true,
              profileId: true,
              createdAt: true,
              updatedAt: true,
              profile: true,
            },
          },
        },
      });
    } catch (error) {
      this.handlePrismaError(error);
    }
  }

  async findAll() {
    return this.prisma.address.findMany({
      orderBy: { createdAt: 'desc' },
      include: {
        user: {
          select: {
            id: true,
            email: true,
            name: true,
            profileId: true,
            createdAt: true,
            updatedAt: true,
            profile: true,
          },
        },
      },
    });
  }

  async findOne(id: string) {
    const address = await this.prisma.address.findUnique({
      where: { id },
      include: {
        user: {
          select: {
            id: true,
            email: true,
            name: true,
            profileId: true,
            createdAt: true,
            updatedAt: true,
            profile: true,
          },
        },
      },
    });

    if (!address) {
      throw new NotFoundException(`Endereço com id ${id} não encontrado.`);
    }

    return address;
  }

  async update(id: string, data: UpdateAddressDto) {
    await this.findOne(id);

    if (data.userId) {
      await this.ensureUserExists(data.userId);
    }

    try {
      return await this.prisma.address.update({
        where: { id },
        data,
        include: {
          user: {
            select: {
              id: true,
              email: true,
              name: true,
              profileId: true,
              createdAt: true,
              updatedAt: true,
              profile: true,
            },
          },
        },
      });
    } catch (error) {
      this.handlePrismaError(error);
    }
  }

  async remove(id: string) {
    await this.findOne(id);

    try {
      return await this.prisma.address.delete({
        where: { id },
        include: {
          user: {
            select: {
              id: true,
              email: true,
              name: true,
              profileId: true,
              createdAt: true,
              updatedAt: true,
              profile: true,
            },
          },
        },
      });
    } catch (error) {
      this.handlePrismaError(error);
    }
  }

  private async ensureUserExists(userId: string) {
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
    });

    if (!user) {
      throw new BadRequestException(
        `O userId ${userId} não existe na tabela User.`,
      );
    }
  }

  private handlePrismaError(error: unknown): never {
    if (error instanceof Prisma.PrismaClientKnownRequestError) {
      if (error.code === 'P2002') {
        throw new ConflictException(
          'Este usuário já possui um endereço cadastrado.',
        );
      }

      if (error.code === 'P2003') {
        throw new BadRequestException(
          'Relacionamento inválido. Verifique se o userId informado existe.',
        );
      }
    }

    throw error;
  }
}
