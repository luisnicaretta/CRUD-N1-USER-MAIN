import { ApiProperty } from '@nestjs/swagger';
import {
  IsInt,
  IsNotEmpty,
  IsString,
  IsUUID,
  Matches,
  Max,
  MaxLength,
  Min,
} from 'class-validator';

export class CreateAddressDto {
  @ApiProperty({ example: 'Rua das Flores' })
  @IsString()
  @IsNotEmpty()
  @MaxLength(150)
  street: string;

  @ApiProperty({ example: 123 })
  @IsInt()
  @Min(1)
  @Max(999999)
  number: number;

  @ApiProperty({ example: 'Goiânia' })
  @IsString()
  @IsNotEmpty()
  @MaxLength(100)
  city: string;

  @ApiProperty({ example: 'GO' })
  @IsString()
  @IsNotEmpty()
  @MaxLength(50)
  state: string;

  @ApiProperty({ example: '74000-000' })
  @IsString()
  @Matches(/^\d{5}-?\d{3}$/)
  zipCode: string;

  @ApiProperty({ example: '7f39d3a1-b3c2-4b3e-8b79-2d5b0ea0cf45' })
  @IsUUID()
  userId: string;
}
