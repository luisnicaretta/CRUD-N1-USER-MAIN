import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  ParseUUIDPipe,
  Patch,
  Post,
} from '@nestjs/common';
import {
  ApiCreatedResponse,
  ApiOkResponse,
  ApiOperation,
  ApiTags,
} from '@nestjs/swagger';
import { AddressService } from './address.service';
import { CreateAddressDto } from './dto/create-address.dto';
import { UpdateAddressDto } from './dto/update-address.dto';

@ApiTags('address')
@Controller('address')
export class AddressController {
  constructor(private readonly addressService: AddressService) {}

  @Post()
  @ApiOperation({ summary: 'Criar um endereço' })
  @ApiCreatedResponse({ description: 'Endereço criado com sucesso.' })
  create(@Body() createAddressDto: CreateAddressDto) {
    return this.addressService.create(createAddressDto);
  }

  @Get()
  @ApiOperation({ summary: 'Listar todos os endereços' })
  @ApiOkResponse({ description: 'Endereços listados com sucesso.' })
  findAll() {
    return this.addressService.findAll();
  }

  @Get(':id')
  @ApiOperation({ summary: 'Buscar um endereço por ID' })
  @ApiOkResponse({ description: 'Endereço encontrado com sucesso.' })
  findOne(@Param('id', new ParseUUIDPipe()) id: string) {
    return this.addressService.findOne(id);
  }

  @Patch(':id')
  @ApiOperation({ summary: 'Atualizar um endereço' })
  @ApiOkResponse({ description: 'Endereço atualizado com sucesso.' })
  update(
    @Param('id', new ParseUUIDPipe()) id: string,
    @Body() updateAddressDto: UpdateAddressDto,
  ) {
    return this.addressService.update(id, updateAddressDto);
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Excluir um endereço' })
  @ApiOkResponse({ description: 'Endereço removido com sucesso.' })
  remove(@Param('id', new ParseUUIDPipe()) id: string) {
    return this.addressService.remove(id);
  }
}
