import { Module } from '@nestjs/common';
import { AddressModule } from './address/address.module';
import { PrismaModule } from './prisma/prisma.module';
import { ProfileModule } from './profile/profile.module';
import { UserModule } from './user/user.module';

@Module({
  imports: [PrismaModule, ProfileModule, UserModule, AddressModule],
})
export class AppModule {}
