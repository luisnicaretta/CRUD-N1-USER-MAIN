import {
  BadRequestException,
  ConflictException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { Prisma, User } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';

@Injectable()
export class UserService {
  constructor(private readonly prisma: PrismaService) {}

  async create(data: CreateUserDto) {
    await this.ensureProfileExists(data.profileId);

    try {
      const user = await this.prisma.user.create({
        data,
        include: {
          profile: true,
          address: true,
        },
      });

      return this.sanitizeUser(user);
    } catch (error) {
      this.handlePrismaError(error);
    }
  }

  async findAll() {
    const users = await this.prisma.user.findMany({
      orderBy: { createdAt: 'desc' },
      include: {
        profile: true,
        address: true,
      },
    });

    return users.map((user) => this.sanitizeUser(user));
  }

  async findOne(id: string) {
    const user = await this.prisma.user.findUnique({
      where: { id },
      include: {
        profile: true,
        address: true,
      },
    });

    if (!user) {
      throw new NotFoundException(`Usuário com id ${id} não encontrado.`);
    }

    return this.sanitizeUser(user);
  }

  async update(id: string, data: UpdateUserDto) {
    await this.findOne(id);

    if (data.profileId) {
      await this.ensureProfileExists(data.profileId);
    }

    try {
      const user = await this.prisma.user.update({
        where: { id },
        data,
        include: {
          profile: true,
          address: true,
        },
      });

      return this.sanitizeUser(user);
    } catch (error) {
      this.handlePrismaError(error);
    }
  }

  async remove(id: string) {
    await this.findOne(id);

    try {
      const user = await this.prisma.user.delete({
        where: { id },
        include: {
          profile: true,
          address: true,
        },
      });

      return this.sanitizeUser(user);
    } catch (error) {
      this.handlePrismaError(error);
    }
  }

  private async ensureProfileExists(profileId: string) {
    const profile = await this.prisma.profile.findUnique({
      where: { id: profileId },
    });

    if (!profile) {
      throw new BadRequestException(
        `O profileId ${profileId} não existe na tabela Profile.`,
      );
    }
  }

  private sanitizeUser<T extends User & { profile?: unknown; address?: unknown }>(
    user: T,
  ) {
    const { password: _password, ...safeUser } = user;
    return safeUser;
  }

  private handlePrismaError(error: unknown): never {
    if (error instanceof Prisma.PrismaClientKnownRequestError) {
      if (error.code === 'P2002') {
        throw new ConflictException('Já existe um usuário com os dados informados.');
      }

      if (error.code === 'P2003') {
        throw new BadRequestException(
          'Relacionamento inválido. Verifique se o profileId informado existe.',
        );
      }
    }

    throw error;
  }
}
